jQuery(document).ready( function() {
   jQuery(".user_like").click( function(e) {
      e.preventDefault(); 
      var fired_button = jQuery(this).val();
     // nonce = jQuery(this).attr("data-nonce");
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : myAjax.ajaxurl,
         data : {action: "my_user_like", post_id : fired_button },
         success: function(response) {
                              jQuery("#app").html('');
                          var content = "<table style='border:1pxsolid green'>"
                            jQuery.each(response[0], function(key, value){
                           // jQuery("#app").append(key + " : " + value + '<br>');
                            content += '<tr style="border:1px solid green" ><td style="border: 1px solid green " >' + key + '</td>:<td style="border: 1px solid green " >' +  value + '</td></tr>';
                             });
                            jQuery('#app').append(content);           
                         }
      });
   });
});